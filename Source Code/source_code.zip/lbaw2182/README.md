# lbaw2182
Online Shop

Eduardo Rui Nascimento Amaral - up201805189@up.pt

João Jorge Azevedo Gonçalves - up201805137@up.pt

João Pedro Martins Rocha - up201805199@up.pt

Nuno Miguel Paiva de Melo e Castro - up202003324@up.pt
