<?php $__env->startSection('title', 'Cards'); ?>

<?php $__env->startSection('content'); ?>
<style>
    .biggerCategory {
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 5px;
    }

    .category {
        border-radius: 10px;
        background-color: #4ACBC9;
        width: 100px;
        height: 100px;
        color: #343434;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: bold;
        margin: 5px;
        text-align: center;
    }

    .category:hover {
        background-color: #8AFCFA;
        width: 105px;
        height: 105px;
    }
</style>

<ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="<?php echo e(url('/home')); ?>">Home</a></li>
    <li class="breadcrumb-item"><a href="<?php echo e(route('user.id', ['id' => auth()->user()->id])); ?>">Admin Tools</a></li>
    <li class=" breadcrumb-item active">Categories Manager</li>
</ol>

<section id="categories">

    <a class="btn btn-outline-primary" href="<?php echo e(route('addCategory')); ?>"> Add Category </a>

    <div class="biggerCategory">
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(route('showCategory', ['category' => $category->id])); ?>">
            <div class="btn btn-outline-dark" style="margin-left: 5px;"><?php echo e($category -> name); ?></div>
        </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>



</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/joao/Desktop/lbaw2182/resources/views/admin/categories.blade.php ENDPATH**/ ?>