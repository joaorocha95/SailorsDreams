<?php $__env->startSection('content'); ?>

<style>
  .smaller {
    width: 300px;
    margin-left: 20px;
  }

  .newProduct {
    align-items: center;
  }
</style>

<fieldset>
  <form method="POST" action="<?php echo e(route('addCategory')); ?>">
    <?php echo e(csrf_field()); ?>

    <Legend>New Category</Legend>
    <div class="form-group row">
      <label for="name" class="col-sm-2 col-form-label">Category Name:</label>
      <div class="col-sm-10"></div>
      <input class="form-control-plaintext smaller" id="name" type="text" name="name" value="<?php echo e(old('name')); ?>" required autofocus>
    </div>
    <?php if($errors->has('name')): ?>
    <span class="error">
      <?php echo e($errors->first('name')); ?>

    </span>
    <?php endif; ?>
    <button type="submit" class="btn btn-primary">
      Submit
    </button>
</fieldset>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/joao/Desktop/lbaw2182/resources/views/admin/categoryNew.blade.php ENDPATH**/ ?>