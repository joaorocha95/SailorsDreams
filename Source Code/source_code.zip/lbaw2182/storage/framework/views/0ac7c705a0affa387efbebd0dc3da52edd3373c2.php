<?php $__env->startSection('title','Edit User'); ?>

<?php $__env->startSection('content'); ?>

<style>
    section {
        width: 100%;
        display: flex;
        flex-wrap: wrap;
        grid-template-columns: 500px 500px 500px;
        justify-content: center;
        justify-self: center;
    }

    form {
        width: 400px;
        text-align: center;
    }

    ::-webkit-input-placeholder {
        text-align: center;
    }

    :-moz-placeholder {
        /* Firefox 18- */
        text-align: center;
    }

    ::-moz-placeholder {
        /* Firefox 19+ */
        text-align: center;
    }

    :-ms-input-placeholder {
        text-align: center;
    }

    label {
        float: left;
    }

    .duoBtn {
        width: fit-content;
        height: fit-content;
        margin-top: 50px;
        margin-left: auto;
        margin-right: auto;
    }
</style>

<ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="<?php echo e(url('/home')); ?>">Home</a></li>
    <li class="breadcrumb-item"><a href="<?php echo e(route('user.id', ['id' => ($id = (auth()->user()->id ) ) ] )); ?>">User Profile</a></li>
    <li class="breadcrumb-item active">Edit User Profile</li>
</ol>


<!--NEW-->
<section>
    <form method="POST" action="<?php echo e(route('editProfile', ['id' => $user->id])); ?>" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

        <?php echo method_field('PATCH'); ?>
        <h2 style="text-align: center;">Edit Profile</h2>
        <label for="phone">Phone Number</label>
        <input id="phone" type="integer" name="phone" value="<?php echo e(old('phone')); ?>" class="form-control" placeholder="Enter phone number" autofocus>
        <?php if($errors->has('phone')): ?>
        <span class="error">
            <?php echo e($errors->first('phone')); ?>

        </span>
        <?php endif; ?>

        <label for="pic" class="form-label mt-4">Profile Image</label>
        <input class="form-control" type="file" id="pic" name="pic">
        <?php if($errors->has('pic')): ?>
        <span class="error">
            <?php echo e($errors->first('pic')); ?>

        </span>
        <?php endif; ?>

        <label for="password" class="form-label mt-4">Password</label>
        <input id="password" type="password" name="password" class="form-control" placeholder="Enter password">
        <?php if($errors->has('password')): ?>
        <span class="error">
            <?php echo e($errors->first('password')); ?>

        </span>
        <?php endif; ?>

        <label for="password-confirm">Confirm Password</label>
        <input id="password-confirm" type="password" name="password_confirmation" class="form-control" placeholder="Confirm password">

        <button type="submit" class="btn btn-primary">
            Confirm
        </button>
    </form>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/joao/Desktop/lbaw2182/resources/views/pages/editUserProfile.blade.php ENDPATH**/ ?>