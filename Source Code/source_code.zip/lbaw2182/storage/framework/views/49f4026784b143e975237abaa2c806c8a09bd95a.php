<?php $__env->startSection('content'); ?>
<title>About</title>

<!-- Fonts -->
<link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">

<script src="https://js.pusher.com/7.0/pusher.min.js"></script>


<!-- Styles -->
<style>
    .temp1 {
        /*
        background-color: #343434;
        */
        font-family: 'Nunito', sans-serif;
        color: #B9B9B9;
        display: flex;
        align-items: center;
        justify-content: center;
        height: 100%;
    }

    #messsage_box {
        width: 400px;
        height: 500px;
        max-height: 400px;
        border-style: solid;
        border-color: black;
        overflow: scroll;
    }

    .message {
        height: 10px;
        color: black;
        margin-left: 5px;
    }

    .message:hover {
        background-color: black;
        color: white;
    }

    .selfMessage {
        background-color: lightblue;
        color: black;
        text-align: right;
        margin-right: 10px;
    }

    .selfMessage:hover {
        background-color: cyan;
    }
</style>


<h2 class="temp1">Order ID: <?php echo e($order->id); ?></h2>
<div class="temp2">
    <div Product: class="temp2"> Product: <?php echo e($product->productname); ?>

    </div>
    <div class="temp2"> Order Status: <?php echo e($order->order_status); ?>

    </div>
    <div class="temp2"> Order Type: <?php echo e($order->order_type); ?>

    </div>
    <div class="temp2"> Loan Start: <?php echo e($order->loan_start); ?>

    </div>
    <div class="temp2"> Loan End: <?php echo e($order->loan_end); ?>

    </div>
    <div class="temp2"> Total Price: <?php echo e($order->total_price); ?>

    </div>
</div>


<script>
    var gIndex = 1;

    function refreshDiv() {
        document.getElementById('target').innerHTML = "Timer " + gIndex++;
        var refresher = setTimeout("refreshDiv()", 1000);
    }
</script>

<body onLoad="refreshDiv()">
    <div id="messsage_box">
        <?php if(Auth::check()): ?>
        <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(auth()->user()->id == $product->seller ): ?>
        <div class="message">{Seller: <?php echo e($message->message); ?></div>
        <?php elseif(auth()->user()->id == $message->sender ): ?>
        <div class="selfMessage">Me: <?php echo e($message->message); ?></div>
        <?php else: ?>
        <div class="message"><?php echo e($message->sender); ?>: <?php echo e($message->message); ?></div>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>
</body>




<form method="POST" action="<?php echo e(route('send')); ?>">
    <label for="message">Write your message:</label>
    <input id="message" type="text" name="text" value="<?php echo e(old('message')); ?>" required autofocus>
    <input type="submit">
    <?php echo e(csrf_field()); ?>

    <?php if($errors->has('message')): ?>
    <span class="error">
        <?php echo e($errors->first('message')); ?>

    </span>
    <?php endif; ?>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/joao/Desktop/lbaw2182/resources/views/messages/test.blade.php ENDPATH**/ ?>