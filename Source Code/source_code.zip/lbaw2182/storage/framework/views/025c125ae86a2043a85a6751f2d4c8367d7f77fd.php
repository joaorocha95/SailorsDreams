<?php $__env->startSection('title', 'Cards'); ?>

<?php $__env->startSection('content'); ?>
<style>
    .userProfile {
        display: table-row;
        min-width: 500px;
        max-width: 500px;
    }

    .profImg {
        min-height: 500px;
        max-height: 500px;
    }

    .geral {
        display: flex;
        flex-wrap: wrap;
        justify-content: center;
        justify-self: center;
        text-align: center;

    }
</style>

<ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="<?php echo e(url('/home')); ?>">Home</a></li>
    <li class="breadcrumb-item active">User Profile</li>
</ol>

<section class="geral">

    <div class="userProfile">
        <div class="card mb-3">
            <h3 class="card-header">Username: <?php echo e($user->username); ?></h3>
            <div class="card-body">
                <h5 class="card-title">Account type: <?php echo e($user->acctype); ?></h5>

            </div>
            <img alt="User Image" src="<?php echo e(asset('uploads/avatarImages/'. $user->img)); ?>" class="profImg"></img>
            <ul class="list-group list-group-flush">
                <li class="list-group-item">Email: <?php echo e($user->email); ?></li>
                <li class="list-group-item">Phone number: <?php echo e($user->phone); ?></li>
                <li class="list-group-item">Birth date: <?php echo e($user->birthdate); ?></li>
            </ul>
            <div class="card-body">
            </div>
        </div>
    </div>



</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/joao/Desktop/lbaw2182/resources/views/pages/outerprofile.blade.php ENDPATH**/ ?>