<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- CSRF Token -->
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

  <!-- <title><?php echo e(config('app.name', 'Laravel')); ?></title>-->
  <title><?php echo $__env->yieldContent('title'); ?></title>

  <!-- Styles -->
  <!--<link href="<?php echo e(asset('css/milligram.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">-->
  <link href="<?php echo e(asset('css/bootstrap.css')); ?>" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">

  <style>
    html {
      height: 100%;
    }

    footer {
      background-color: #1a1a1a;
      position: absolute;
      right: 0;
      bottom: 0;
      left: 0;
      height: 200px;
      color: white;

    }

    body {
      position: relative;
      margin: 0;
      padding-bottom: 200px;
      min-height: 100%;
      z-index: -999;
    }

    .column {
      float: left;
      width: 25%;
      padding: 10px;
      height: 200px;
      color: white;
      text-align: center;
    }

    /* Clear floats after the columns */
    .row:after {
      content: "";
      display: table;
      clear: both;
    }

    /* Responsive layout - makes the three columns stack on top of each other instead of next to each other */
    @media  screen and (max-width: 600px) {
      .column {
        width: 100%;
      }
    }

    h3 {
      color: white;
    }

    .breadcrumb {
      margin-left: 15px;
      margin-top: 15px;
    }

    .footer-link {
      color: white;
    }

    .column p {
      color: white;
    }
  </style>

  <script type="text/javascript">
    // Fix for Firefox autofocus CSS bug
    // See: http://stackoverflow.com/questions/18943276/html-5-autofocus-messes-up-css-loading/18945951#18945951
  </script>
  <script type="text/javascript" src="<?php echo e(asset('js/app.js')); ?>" defer>
  </script>
</head>

<body class="antialiased">
  <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <div class="container-fluid">
      <a class="navbar-brand" href="<?php echo e(url('/home')); ?>">Sailor's Dream</a>
      <button id="dpdHeader_btn" class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarColor01" aria-controls="navbarColor01" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarColor01">
        <ul class="navbar-nav me-auto">
          <li class="nav-item">
            <div class="buttons">
            </div>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo e(url('/categories')); ?>"> Categories </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo e(url('/products')); ?>"> Products </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('help')); ?>"> Help</a>
          </li>
          <li>
            <a class="nav-link" href="<?php echo e(url('/about')); ?>"> About Us</a>
          </li>
        </ul>
        <form action="<?php echo e(route('products')); ?>" method="GET" role="search" class="d-flex">
          <input class="form-control me-sm-2" type="text" placeholder="Search Products" name="term" id="term">
          <button class="btn btn-outline-light my-2 my-sm-0" type="submit">Search</button>
        </form>
        <?php if(Auth::check()): ?>
        <?php if(Auth::user()->acctype == 'Admin'): ?>
        <a class="btn btn-outline-light" style="margin-left: 5px;" href="<?php echo e(route('user.id', ['id' => ($id = (auth()->user()->id ) ) ] )); ?>"> Admin Tools </a>
        <?php else: ?>
        <a class="btn btn-outline-light" style="margin-left: 5px;" href="<?php echo e(route('user.id', ['id' => ($id = (auth()->user()->id ) ) ] )); ?>"> User Profile </a>
        <?php endif; ?>
        <a class="btn btn-outline-light" style="margin-left: 5px;" href="<?php echo e(url('/logout')); ?>"> Logout </a> <span><?php echo e(Auth::user()->name); ?></span>
        <?php else: ?>
        <a class="btn btn-outline-light" style="margin-left: 5px;" href="<?php echo e(url('/login')); ?>"> Login </a>
        <?php endif; ?>
      </div>
    </div>
  </nav>


  <?php echo $__env->yieldContent('content'); ?>

  </main>
  </section>
  <footer>
    <div class="column">
      <a href="<?php echo e(url('/categories')); ?>">
        <h3>Categories</h3>
      </a>
    </div>
    <div class="column">
      <?php if(auth()->check()): ?>
      <a href="<?php echo e(route('user.id', ['id' => ($id = (auth()->user()->id ) ) ] )); ?>">
        <h3>User Profile</h3>
        <a href="<?php echo e(route('editProfile', ['id' => ($id = (auth()->user()->id ) ) ] )); ?>">
          <p href="">Edit Profile</p>
        </a>
        <a href="<?php echo e(route('orders')); ?>">
          <p>Orders</p>
        </a>
        <a>
          <p>Wishlist</p>
        </a>
      </a>
      <?php else: ?>
      <a href="<?php echo e(url('/login')); ?>">
        <h3>User Profile</h3>
        <a href="<?php echo e(url('/login')); ?>">
          <p href="">Edit Profile</p>
        </a>
        <a href="<?php echo e(url('/login')); ?>">
          <p>Orders</p>
        </a>
        <a href="<?php echo e(url('/login')); ?>">
          <p>Wishlist</p>
        </a>
      </a>
      <?php endif; ?>
    </div>
    <div class="column">
      <a href="<?php echo e(url('/about')); ?>">
        <h3>About Us</h3>
      </a>
    </div>
    <div class="column">
      <a href="<?php echo e(url('/help')); ?>">
        <h3>Help</h3>
      </a>
      <a>
        <p>Send Ticket</p>
      </a>
      <a href="<?php echo e(url('/help/faq')); ?>">
        <p>FAQ</p>
      </a>
  </footer>
</body>

<script>
  const dpdHeader_btn = document.getElementById("dpdHeader_btn");
  const navBarColor01 = document.getElementById("navbarColor01");
  dpdHeader_btn.addEventListener("click", function() {
    if (navBarColor01.classList.contains("show"))
      navBarColor01.classList.remove("show");
    else navBarColor01.classList.add("show");
  });
</script>

</html><?php /**PATH /home/joao/Desktop/lbaw2182/resources/views/layouts/app.blade.php ENDPATH**/ ?>