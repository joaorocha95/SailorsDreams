<?php $__env->startSection('content'); ?>
<title>About</title>

<!-- Fonts -->
<link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">

<!-- Styles -->
<style>
    h2 {
        margin: 10px;
    }
</style>

<ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="<?php echo e(url('/home')); ?>">Home</a></li>
    <li class="breadcrumb-item"><a href="<?php echo e(route('user.id', ['id' => auth()->user()->id])); ?>">Admin Tools</a></li>
    <li class="breadcrumb-item"><a href="<?php echo e(url('/admin/categories')); ?>">Categories Manager</a></li>
    <li class=" breadcrumb-item active">Category</li>
</ol>

<h2>Category name: <?php echo e($category->name); ?></h2>

<a class="btn btn-outline-primary" href="<?php echo e(route('updateCategory', ['category' => $category->id])); ?>"> Edit Category </a>

<form method="POST" action="<?php echo e(route('deleteCategory', ['category' => $category->id])); ?>">
    <?php echo method_field('DELETE'); ?>
    <?php echo csrf_field(); ?>
    <div class="input-group">
        <button class="btn btn-outline-primary" type="submit">
            Delete product
        </button>
    </div>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/joao/Desktop/lbaw2182/resources/views/admin/categoryDetails.blade.php ENDPATH**/ ?>