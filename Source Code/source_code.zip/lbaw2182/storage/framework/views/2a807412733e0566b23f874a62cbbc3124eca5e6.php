<?php $__env->startSection('content'); ?>

<?php $__env->startSection('title','Login'); ?>
<style>
    section {
        width: 100%;
        display: flex;
        flex-wrap: wrap;
        grid-template-columns: 500px 500px 500px;
        justify-content: center;
        justify-self: center;
    }

    form {
        width: 400px;
        text-align: center;
    }

    ::-webkit-input-placeholder {
        text-align: center;
    }

    :-moz-placeholder {
        /* Firefox 18- */
        text-align: center;
    }

    ::-moz-placeholder {
        /* Firefox 19+ */
        text-align: center;
    }

    :-ms-input-placeholder {
        text-align: center;
    }

    label {
        float: left;
    }

    .duoBtn {
        width: fit-content;
        height: fit-content;
        margin-top: 50px;
        margin-left: auto;
        margin-right: auto;
    }
</style>

<ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="<?php echo e(url('/home')); ?>">Home</a></li>
    <li class=" breadcrumb-item active">Login</li>
</ol>
<!--OLD -->
<section>
    <form method="POST" action="<?php echo e(route('login')); ?>">
        <?php echo e(csrf_field()); ?>

        <h2 style="text-align: center;">Login</h2>
        <div class="form-group">
            <label for="email" class="form-label mt-4">E-mail</label>
            <input id="email" type="email" name="email" value="<?php echo e(old('email')); ?>" class="form-control" placeholder="Enter email" required autofocus>
            <?php if($errors->has('email')): ?>
            <span class="error">
                <?php echo e($errors->first('email')); ?>

            </span>
            <?php endif; ?>
        </div>

        <label for="password" class="form-label mt-4">Password</label>
        <input id="password" type="password" name="password" class="form-control" placeholder="Enter password" required>
        <?php if($errors->has('password')): ?>
        <span class="error">
            <?php echo e($errors->first('password')); ?>

        </span>
        <?php endif; ?>
        <?php if(session('error')): ?>
        <div class="alert alert-danger">
            <?php echo e(session('error')); ?>

        </div>
        <?php endif; ?>
        <div class="duoBtn">
            <button type="submit" class="btn btn-primary">
                Login
            </button>
            <a href="<?php echo e(route('register')); ?>" class="btn btn-primary">Register</a>
        </div>
    </form>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/joao/Desktop/lbaw2182/resources/views/auth/login.blade.php ENDPATH**/ ?>