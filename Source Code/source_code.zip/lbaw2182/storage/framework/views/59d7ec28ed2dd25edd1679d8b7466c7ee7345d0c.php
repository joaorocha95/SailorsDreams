<?php $__env->startSection('content'); ?>

<?php $__env->startSection('title','Order Page'); ?>

<!-- Fonts -->
<link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">

<!-- Styles -->
<style>
    .temp1 {
        /*
        background-color: #343434;
        */
        font-family: 'Nunito', sans-serif;
        color: #B9B9B9;
        display: flex;
        align-items: center;
        justify-content: center;
        height: 100%;
    }

    #messsage_box {
        width: 400px;
        height: 500px;
        max-height: 400px;
        border-style: solid;
        border-color: black;
        overflow: scroll;
    }

    .message {
        height: 10px;
        color: black;
        margin-left: 5px;
    }

    .message:hover {
        background-color: black;
        color: white;
    }

    .selfMessage {
        background-color: lightblue;
        color: black;
        text-align: right;
        margin-right: 10px;
    }

    .selfMessage:hover {
        background-color: cyan;
    }

    .orderProfile {
        display: table-row;
        min-width: 500px;
        max-width: 500px;
    }

    .productImg>img {
        width: 100%;
    }

    .geral {
        display: flex;
        flex-wrap: wrap;
        justify-content: center;
        justify-self: center;
        text-align: center;

    }
</style>

<ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="<?php echo e(url('/home')); ?>">Home</a></li>
    <li class="breadcrumb-item"><a href="<?php echo e(route('user.id', ['id' => ($id = (auth()->user()->id ) ) ] )); ?>">User Profile</a></li>
    <li class="breadcrumb-item"><a href="<?php echo e(route('orders')); ?>">Orders</a></li>
    <li class="breadcrumb-item active">Order Status</li>
</ol>

<h2 class="temp1">Order ID: <?php echo e($order->id); ?></h2>

<section class="geral">

    <div class="orderProfile">
        <div class="card mb-3">
            <h3 class="card-header">Product: <?php echo e($product->productname); ?></h3>
            <div class="card-body">
                <h5 class="card-title">Order Status: <?php echo e($order->order_status); ?></h5>

            </div>
            <a class="productImg" href="<?php echo e(route('products.id', ['id' => $product->id])); ?>">
                <img alt="Product Image" src="<?php echo e(asset('uploads/productImages/'. $product->img)); ?>" class="productImg"></img>
            </a>
            <ul class="list-group list-group-flush">
                <li class="list-group-item">Order Type: <?php echo e($order->order_type); ?></li>
                <li class="list-group-item">Loan Start: <?php echo e($order->loan_start); ?></li>
                <li class="list-group-item">Loan End: <?php echo e($order->loan_end); ?></li>
                <li class="list-group-item">Total Price: <?php echo e($order->total_price); ?>€</li>
            </ul>
            <?php if(Auth::check()): ?>
            <div class="card-body">

                <?php if(Auth::user()->acctype == 'Client'): ?>
                <a class="btn btn-outline-primary" href="<?php echo e(route('newReview.id', ['id' => $order->id])); ?>"> Review Order</a>
                <?php endif; ?>

                <?php if(Auth::user()->acctype == 'Seller'): ?>

                <?php if($order->order_status == 'In_Negotiation'): ?>

                <form method="POST" action="<?php echo e(route('endOrder', [$order->id])); ?>">
                    <?php echo e(csrf_field()); ?>

                    <?php echo method_field('PATCH'); ?>
                    <button type="submit" class="btn btn-outline-primary">
                        Complete Order
                    </button>
                </form>

                <form method="POST" action="<?php echo e(route('cancelOrder', [$order->id])); ?>">
                    <?php echo e(csrf_field()); ?>

                    <?php echo method_field('PATCH'); ?>
                    <button type="submit" class="btn btn-outline-primary">
                        Cancel Order
                    </button>
                </form>
                <?php endif; ?>
                <?php endif; ?>
            </div>
            <?php endif; ?>
        </div>
    </div>



</section>


</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/joao/Desktop/lbaw2182/resources/views/orders/order.blade.php ENDPATH**/ ?>